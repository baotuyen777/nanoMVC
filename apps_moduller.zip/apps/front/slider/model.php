<?php
class userModel extends Model {

    public $table = "menu";

    public function __construct() {
        parent::__construct();
    }

}
