<?php

class UserController extends Controller {

    function __construct($app, $module) {
        parent::__construct($app, $module);
    }


}
