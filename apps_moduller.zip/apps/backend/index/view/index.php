<?php
$timthumb = SITE_ROOT . 'libs/timthumb.php?src=';
?>
<div class="container">
    Hello kitty

</div> <!-- /container -->