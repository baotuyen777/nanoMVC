<?php

class productcatController extends Controller {

    function __construct($app, $module) {
        parent::__construct($app, $module);
    }


}
