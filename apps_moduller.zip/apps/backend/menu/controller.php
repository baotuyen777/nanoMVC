<?php

class menuController extends Controller {

    function __construct($app, $module) {
        parent::__construct($app, $module);
    }

    

}
