<?php

class productController extends Controller {

    function __construct($app, $module) {
        parent::__construct($app, $module);
    }

    

}
