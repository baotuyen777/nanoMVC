<?php

class SliderController extends Controller {

//    protected $object = 'slider';

    function __construct($app, $module) {
        parent::__construct($app, $module);
    }

    

}
