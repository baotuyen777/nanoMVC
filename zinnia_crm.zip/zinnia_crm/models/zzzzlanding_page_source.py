# -*- coding:utf-8 -*-
from odoo import fields, models, api
class lps(models.Model):
    _name = 'crm.lps'
    code=fields.Char(string='Code',required=True)
    name=fields.Char(string="Name")
    total = fields.Integer(string='Total Partner', compute='partner_used') 
    @api.multi
    def partner_used(self):
        for lps in self:
            partner_cnt = self.env['res.partner'].search_count([('lps_id','=', lps.id)])
            lps.total=partner_cnt