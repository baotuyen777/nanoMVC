# -*- coding:utf-8 -*-
from odoo import models, fields,api
from datetime import datetime,timedelta
class CaseRefCareTime(models.Model):
    _name = 'crm.case_ref_care_time'
    _order = 'id desc'
    case_id = fields.Many2one('crm.case', 'case_id')
    care_time_id = fields.Many2one('crm.care_time', 'care_time_id')
    care_name=fields.Char(related='care_time_id.name')
    create_date = fields.Datetime('Create Date',default=fields.datetime.now())
    write_date = fields.Datetime('Write Date')
    create_uid = fields.Many2one('res.users', 'Create User')
    write_uid = fields.Many2one('res.users', 'Write User',default=lambda self: self.env.user.id, readonly=True)
    is_cared = fields.Boolean('Is cared')
    # is_satisfy = fields.Boolean()

class CaseRefCareTimeView(models.Model):
    _name = 'crm.case_ref_care_time_view'
    _order = 'id desc'
    _auto = False
    _sql = """CREATE OR REPLACE VIEW crm_case_ref_care_time_view AS
        select row_number() over () id ,a.id as case_id,b.id as care_time_id, 
                c.create_date,c.write_date,c.create_uid,c.write_uid, c.is_cared
        from crm_case a inner join crm_case_ref_care_time c on a.id=c.case_id
                        inner join crm_care_time b on b.id=c.care_time_id"""
    id = fields.Integer('Id')
    name=fields.Char()
    # is_process = fields.Boolean('Is cared')
    case_id=fields.Many2one('crm.case','case_id')

    care_time_id=fields.Many2one('crm.care_time','care_time_id')
    care_name = fields.Char(related='care_time_id.name')
    create_date = fields.Datetime('Create Date')
    write_date = fields.Datetime('Write Date')
    create_uid = fields.Many2one('res.users', 'Create User')
    write_uid = fields.Many2one('res.users', 'Write User')
    is_cared = fields.Boolean('Is cared')
    # is_satisfy = fields.Boolean('Is satisty')
    # date=fields.datetime('Date care')

    def mark_cared(self):
        # print self.case_id
        # print self.care_time_id
        current_time=  datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        query_cmd = """ UPDATE crm_case_ref_care_time 
                                set is_cared= %s,write_date='%s'
                                WHERE case_id = %d and care_time_id=%d 
                     """ % (not self.is_cared ,current_time,self.case_id.id,self.care_time_id.id)
        self.env.cr.execute(query_cmd)
        # add care_time_history
        if not self.is_cared:
            self.add_care_time_history(self.case_id,self.care_name)

        # return {
        #     "name": "List Care time ",
        #     "view_type": "form",
        #     "view_mode": "tree",
        #     "res_model": "crm.case_ref_care_time_view",
        #     "view_id": False,
        #     "type": 'ir.actions.act_window',
        #     "target": 'new',
        #     "readonly": True,
        #     "domain":[('case_id','=',self.case_id.id)],
        # }
    def add_care_time_history(self,case,care_name):
        current_date = datetime.now().date()
        for care_time in case.product_id.care_time_id:
            day_care = datetime.strptime(case.apm_time, "%Y-%m-%d %H:%M:%S") + timedelta(days=care_time.number_day)
            if day_care.date() <= current_date:
                is_satisfy = True
                # check condition
                if care_time.condition:
                    arr_condition = care_time.condition.split((','))
                    is_satisfy = False
                    for condition in arr_condition:
                        for care_time_his in case.care_time_history_id:
                            if care_time_his.care_name == condition:
                                is_satisfy = True
                                if care_name==care_time_his.care_name:
                                    continue
                                if not care_time_his.is_cared:
                                    is_satisfy = False
                                    break
                if (is_satisfy):
                    case.write({'care_time_id': [(4, care_time.id)]})
        # crc.write({'is_cared': not self.is_cared })
# class CareTimeTransient(models.TransientModel):
#     _name = 'crm.care_time_transient'
#     treatment_times = fields.Integer('Times number')
#     treatment_day = fields.Integer('Number day in next times')
#
#     @api.multi
#     def insert_data(self):
#         active_ids= self._context.get('active_ids')
#         data={}
#         if self.treatment_times !=0:
#             data['treatment_times'] =self.treatment_times
#         if self.treatment_day !=0:
#             data['treatment_day'] =self.treatment_day
#         for product_id in active_ids:
#             self.env['product.product'].search([('id','=',product_id)]).write(data)
#         return True

