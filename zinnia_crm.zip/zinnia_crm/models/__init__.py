# -*- coding: utf-8 -*-

from . import partner
from . import partner_properties
from . import case
from . import case_properties
from . import phone_call
from . import phone_call_properties
from . import product

from . import agency
from . import maketing_campaign
from . import service_type
from . import progress
from . import maketing_channel
#
from . import reminder
from . import branch

from . import employee_properties
from . import user
from . import employee
from . import employee_job_type
# # sms
from . import sms
from . import sms_gateway
from . import sms_type
from . import api_oauth_config
# care
from . import care_time
from . import case_ref_care_time