# -*- coding:utf-8 -*-

from odoo import fields, models, api
class ContactType(models.Model):
    _name = "crm.contact_type"
    name=fields.Char(string="Description",required=True)
    code=fields.Char(string="Code",required=True)
