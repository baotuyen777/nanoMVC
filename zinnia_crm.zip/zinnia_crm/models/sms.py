# -*- coding: utf-8 -*-
from odoo import fields, models, api, exceptions
from dateutil import tz
import math
from helper import replace_sms_temp, create_sms_to_queue
from datetime import datetime
from PyQt4.Qt import Display


class Sms(models.Model):
    _name = 'crm.sms'
    _order = 'id desc'
    case_id = fields.Many2one('crm.case', string='Case', required=False, readonly=True)
    apm_time = fields.Datetime(string='Appointment send time', required=True)
    msg = fields.Text(string='Message content', required=True)
    type_id = fields.Many2one('crm.sms_type', 'Type', required=True)
    # type=fields.Selection([
    #     ('order','Appointment Reminder'),
    #     ('using','Treatment Reminder'),
    # ],string='Type',required=True)
    state = fields.Selection([
        ('pending', 'Pending'),
        ('sent', 'Sent'),
    ], string='State', readonly=False, default='pending')

    # gateway_id = fields.Many2one('crm.sms_gateway', string="SMS Gateway")
    # extra
    case_state = fields.Selection(related='case_id.state', string="Case state", readonly=True)
    mobile = fields.Char(string="Mobile No", related='customer_id.mobile', readonly=True, require=False, store=True)
    #mobile = fields.Many2one('crm.partner_phone', string="Mobile No", domain="[('phone_type','=','mobile'),('customer_id','=',customer_id)]")        
    customer_id = fields.Many2one(related='case_id.customer_id', string="Customer", readonly=True, store=True)    
    created_by = fields.Many2one('res.users', string="Employee", default=lambda self: self.env.user.id, readonly=True)
    created_date = fields.Datetime('Create date', readonly=True, default=fields.datetime.now())
    product_id = fields.Many2one(related='case_id.product_id', readonly=True)

    def send_sms_scheduler_queue(self):
        # print "send sms scheduler"
        # print(datetime.now())
        rtime = '07:00'
        current_time = datetime.utcnow()
        current_date = datetime.now().date()
        from_zone = tz.gettz('UTC')
        to_zone = tz.gettz(self.env.user.tz) or tz.gettz('Asia/Saigon')
        # to_zone = self.env.user.tz or tz.gettz('Asia/Saigon')
        arr_sms = self.env['crm.sms'].search(
            [
                '&'
                , ('state', '=', 'pending')
                , ('apm_time', '>=', datetime.strftime(current_date, "%Y-%m-%d %H:%M:%S"))
                , ('apm_time', '<=', datetime.strftime(current_date, "%Y-%m-%d 23:59:59"))
            ]
            , limit=10, order="apm_time desc")
        time_now = current_time.replace(tzinfo=from_zone).astimezone(to_zone).strftime("%H:%M")
        for sms in arr_sms:
            if (sms.type_id.reminder_time):
                hr = math.floor(sms.type_id.reminder_time)
                mi = math.ceil((sms.type_id.reminder_time - hr) * 60)
                if mi < 10:
                    rtime = str(int(hr)) + ':0' + str(int(mi))
                else:
                    rtime = str(int(hr)) + ':' + str(int(mi))
            if (datetime.strptime(time_now, "%H:%M") > datetime.strptime(rtime, "%H:%M")):
                sms.write({'state': 'sent'})    
           
    def create_treatment_sms_scheduler(self):  
        # print('Using SMS scheduler is running......')
        current_time = datetime.now()
        from_zone = tz.gettz('UTC')
        # to_zone = self.env.user.tz or tz.gettz('Asia/Saigon')
        to_zone = tz.gettz(self.env.user.tz) or tz.gettz('Asia/Saigon')
        hr_start = int(current_time.replace(tzinfo=from_zone).astimezone(to_zone).strftime("%H"))
        if hr_start >=2:  # and hr_start <= 3           
            case_lst = self.env['crm.case'].search(
                ['&',
                 ('state', 'in', ['order', 'using']),
                 ('is_queued', '=', False),
                 ('product_id.treatment_times', '>', '1'),
                 ('apm_end_time', '>=', datetime.now().strftime('%Y-%m-%d')),
                 ])
            for case in case_lst:                
                vals = {}
                if case.state=='order':
                    vals={
                           'branch_id': case.branch_id.id,
                           'apm_time': case.apm_time, 
                        }
                create_sms_to_queue(self, case, case.state, vals)
                
    def create_brithday_sms_scheduler(self):  
        #print('Birthday SMS scheduler is running......')
        current_time = datetime.now()
        from_zone = tz.gettz('UTC')        
        to_zone = tz.gettz(self.env.user.tz) or tz.gettz('Asia/Saigon')
        locate_tz = current_time.replace(tzinfo=from_zone).astimezone(to_zone)
        hr_start = locate_tz.strftime("%H:%M")     
        if hr_start >2: 
            #== "13:54":            
            partners = self.env['res.partner'].search([('birth', 'ilike', locate_tz.strftime('%m-%d'))])
            for partner in partners:
                vals = {
                        'customer_id' : partner.id,
                        'mobile': partner.mobile,
                        'apm_time': datetime.now().strptime((datetime.now()).strftime('%Y-%m-%d'), '%Y-%m-%d'),
                     }                    
                create_sms_to_queue(self, None, 'birthday', vals)               

    def resend_sms(self):
        case_id= self._context.get('case_id')
        arr_sms=self.env['crm.sms'].search([('case_id','=',case_id)],limit=1)             
        replace_sms_temp(arr_sms.msg, args_dict={})        
        raise exceptions.ValidationError('Send sms success')
    
    def create_direct_sms(self):
        ctx = self._context;
        self.type_id =  ctx['default_type_id']
        self.mobile =  ctx['default_mobile']
        self.customer_id = ctx['default_customer_id']
        dict={}
        self.msg = replace_sms_temp(self.msg,dict)
        self.send_direct_sms()
    
    def send_direct_sms(self):           
        sms = self.env['crm.sms'].search([('id','=',self.id)])      
        cur_date = datetime.strptime(sms['apm_time'], '%Y-%m-%d %H:%M:%S').date()        
        send_date = datetime.strptime(datetime.strftime(datetime.now(), "%Y-%m-%d"), "%Y-%m-%d").date()
        if cur_date==send_date:            
            sms.write({'state': 'sent'})
    
    @api.onchange('apm_time')
    def over_date_chg(self):
        _apm_time = datetime.strptime(self.apm_time, '%Y-%m-%d %H:%M:%S')        
        _bef_date = datetime.now().strptime((datetime.now()).strftime('%Y-%m-%d'), '%Y-%m-%d')
        if self.apm_time and (_apm_time < _bef_date):
            return {
                'error': {
                    'title': "Warning!",
                    'message': "The Appointment time must be equal or greater than today!",
                },
            }
 
    @api.constrains('apm_time')
    def over_date_cnst(self):           
        _apm_time = datetime.strptime(self.apm_time, '%Y-%m-%d %H:%M:%S')        
        _bef_date = datetime.now().strptime((datetime.now()).strftime('%Y-%m-%d'), '%Y-%m-%d')
        if self.apm_time and _apm_time < _bef_date:
            return Warning('The Appointment time must be equal or greater than today!')
        
    @api.onchange('case_id')
    def get_sms_properties(self):
        self.apm_time = self.case_id.apm_time
        case_state = self.case_id.state
        if (case_state in ['order', 'using']):
            sms_type = self.env['crm.sms_type'].search([('state', '=', case_state)], limit=1)
            if sms_type:
                self.type_id = sms_type.id
                # msg                
                self.msg = sms_type.template
                args_dict = {
                    '[service]': (self.case_id.product_id.name),
                    '[location]': (self.case_id.branch_id.name),
                    '[date]': self.apm_time,
                    '[hline]': '04 33926888',
                }
                self.msg = replace_sms_temp(sms_type.template, args_dict)    
    @api.multi
    def name_get(self):
        result = []
        if self.customer_id:
            if self.ensure_one():           
                name = self.customer_id.name + '-' + self.customer_id.mobile if self.customer_id.mobile else ''
                result.append((self.id, name))
        return result   
        
    