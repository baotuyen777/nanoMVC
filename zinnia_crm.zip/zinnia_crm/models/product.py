# -*- coding: utf-8 -*-
from odoo import api, fields, models

class ProductProduct(models.Model):
    _inherit = 'product.product'
    treatment_times =fields.Integer('Treatment times',default=1 )
    treatment_day =fields.Integer(string='Number day in next times')
    care_time_id=fields.One2many('crm.care_time','product_id', 'Care time')
    group_id=fields.Many2one('crm.product_group','Product group')
    # type_id = fields.Char(related, 'Product type')
    # treatment_day=fields.Integer('Number day in next times')
    # treatment_times=fields.Integer('Number day in next times')
    def action_update_quick(self):
        return {
            "name": "Update Quickly ",
            "view_type": "form",
            "view_mode": "form",
            "res_model": "crm.product_transient",
            "view_id": False,
            "type": 'ir.actions.act_window',
            "target": 'new',
            "readonly": True,
            "context": {
                "active_ids":self._context.get('active_ids')
            },
        }
class ProductGroup(models.Model):
    _name = 'crm.product_group'
    name=fields.Char('Name',required=True)
    code=fields.Char('Code',required=True)
    type_id=fields.Many2one('crm.product_type','Product type',required=True)
class ProductType(models.Model):
    _name = 'crm.product_type'
    name=fields.Char('Name',required=True)
    code=fields.Char('Code',required=True)


class ProductTransient(models.TransientModel):
    _name = 'crm.product_transient'
    treatment_times = fields.Integer('Times number')
    treatment_day = fields.Integer('Number day in next times')

    @api.multi
    def insert_data(self):
        active_ids= self._context.get('active_ids')
        data={}
        if self.treatment_times !=0:
            data['treatment_times'] =self.treatment_times
        if self.treatment_day !=0:
            data['treatment_day'] =self.treatment_day
        for product_id in active_ids:
            self.env['product.product'].search([('id','=',product_id)]).write(data)
        return True
