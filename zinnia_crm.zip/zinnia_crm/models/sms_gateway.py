# -*- coding: utf-8 -*-
from odoo import fields, models

class smsGateway(models.Model):
    _name = 'crm.sms_gateway'
    name = fields.Char(string='Gateway name', required=True)
    server = fields.Char(required=True, string='Gateway url')    
    api_method = fields.Selection([
            ('http', 'HTTP Method'),
            ('smpp', 'SMPP Method')
        ])
    parameter = fields.Many2many('crm.sms_gateway_parameter', 'gateway_ref_parameter', 'gateway_id', 'param_id', string='Parameter')
    employee = fields.Many2many('hr.employee', 'gateway_ref_employee', 'gateway_id', 'emp_id', string='Permission')
    
    validity = fields.Char(string='Validity', default='10')
    classes = fields.Selection([
            ('flat', 'Flat'),
            ('phone_disp', 'Phone display'),
            ('sim', 'SIM'),
            ('toolk', 'Took kit'),
        ], string='Class') 
    feferred = fields.Char(string='Feferred', default='0')
    no_stop = fields.Boolean(string='NoStop', default=True)
    priority = fields.Selection([
        ('0', '0'),
        ('1', '1'),
        ('2', '2'),
        ('3', '3'),
        ], string='Priority')
    coding = fields.Selection([
        ('7b', '7 bit'),
        ('u', 'Unicode')
        ], string='Coding')
    tag = fields.Char(string='Tag')
    character_limit = fields.Boolean('Character Limit', default=True)    
class smsGatewayParameter(models.Model):
    _name = 'crm.sms_gateway_parameter'
    _order = 'id desc'    
    api_method = fields.Selection(
        [('usr', 'User'),
         ('psd', 'Password'),
         ('send', 'Sender name'),
         ('recp', 'Recipient No'),
         ('sms', 'SMS message'),
         ('ext', 'Extra infor')
        ], string='API Method')
    prop_name = fields.Char(string='Property name')
    prop_value = fields.Char(string='Property value')
