# -*- coding: utf-8 -*-
from odoo import fields, models,api
from datetime import datetime
class treatmentCard(models.Model):
    _name = 'crm.treatment_card'
    name=fields.Char(string="Code card",required=True)
    customer_id=fields.Many2one('res.partner', string="Customer",required=True)
    value=fields.Char(string='Value',default=0,readonly=True)
    residual_value=fields.Integer(string='Residua value')
    use_value=fields.Integer(string='Use value')
    amount_debit=fields.Integer(string="Amount debit")
    order_id=fields.Char()
    type=fields.Selection([
        ('cnc','CNC card'),
        ('skincare','SkinCare card'),
        ('pcell',"P'Cell card"),

    ])
    product_id=fields.Many2one('product.product','Treatment')
    start_date=fields.Date(string="Start date",required=True,default=datetime.now().strftime('%Y-%m-%d'))
    end_date=fields.Date(string="Deadline")
    times=fields.Integer(string="Times")
    residual_times=fields.Integer(string="Residual times")
    sale_off=fields.Float(string='Sale off')
    card_form=fields.Selection([
        ('diplomatic','Diplomantic card'),
        ('residual','Residual up card'),
        ('maketing','Maketing card'),
    ])
    note=fields.Text(string="infomation")
    state=fields.Selection([
        ('draft',"Draft"),
        ('gave',"Gave out to customer"),
        ('returned',"Returned"),
    ])
    @api.multi
    def action_draft(self):
        self.state='draft'
    @api.multi
    def action_gave(self):
        self.state='gave'
    @api.multi
    def action_returned(self):
        self.state='returned'
