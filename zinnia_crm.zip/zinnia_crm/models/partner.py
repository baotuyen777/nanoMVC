# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from datetime import datetime as dt, timedelta

class Partner(models.Model):
    _inherit = 'res.partner'
    _order = 'id desc'
    # Add a new column to the res.partner model, by default partners are not
    # instructors
    #instructor = fields.Boolean("Instructor", default=False)
    code = fields.Char(string="Code", default=lambda self:self.code_gender(), readonly=True)
    #phone=fields.Char(string='Phone')
    mobile = fields.Char(string='Mobile', required=True)
    # lps_id = fields.Many2one('crm.lps', string="Landing Page Source")

    birth = fields.Date(string="Birthday")
    country_id = fields.Many2one('res.country',string='', default=lambda self:self.select_default_country() )
    # landing_page_source=fields.Char()
    contact_type=fields.Many2one('crm.contact_type','Contact type')
    reference=fields.Char()
    case_ids=fields.One2many('crm.case','customer_id',string='Case list')
    sms_id=fields.One2many('crm.sms', 'customer_id')
    # member_level=fields.Many2one('crm.member_level',string='Member Level')
    member_level=fields.Selection([
        ('siliver','Bac'),
        ('gold', 'Vang')
    ],string='Member Level')

    gender = fields.Selection([
        ('male','Male'),
        ('female','Female'),
        ('unknow','Unknow')
    ], default='female', required=True)
    branch=fields.Many2one('crm.branch','Branch')
    maketing_channel=fields.Many2one('crm.maketing_channel','Maketting Channel')
    phones=fields.One2many('crm.partner_phone', 'customer_id', string='Partner phones', required=True)
    district=fields.Many2one('crm.district', string='Partner district')
    state_id=fields.Many2one('res.country.state')
    _sql_constraints = [
        ('mobile_uniq',
         'UNIQUE (mobile)',
         'Mobile must be unique.'),
        ('phone_uniq',
         'UNIQUE (phone)',
         'Phone must be unique.'),
        ('code_uniq',
         'UNIQUE (code)',
         'Code must be unique.'),
        ('email_uniq',
         'UNIQUE (email)',
         'Email must be unique.'),
    ]
    # @api.multi
    # def scan_partner_partner_scheduler(self):
    #     print 'scan partner'
    #     current_date = dt.now().date()
    #     arr_case=self.env['crm.case'].search([('state','=','using')])
    #     print arr_case
    #     for case in arr_case:
    #         for care_time in case.product_id.care_time_id:
    #             day_care = dt.strptime(case.apm_time, "%Y-%m-%d %H:%M:%S") + timedelta(days=care_time.number_day)
    #             print day_care
    #             arr_condition= care_time.condition.split(',')
    #
    #             if day_care.date() == current_date:
    #                 case.customer_id.write({'is_caring':True})
    #                 print 'have some people added'




    # @api.one
    # def _check_caring(self):
    #     self.ensure_one()
    #     current_date = dt.now().date()
    #     for case in self.case_ids:
    #         if case.state == 'using':
    #             for care_time in case.product_id.care_time_id:
    #                 day_care=dt.strptime(case.apm_time, "%Y-%m-%d %H:%M:%S") + timedelta(days=care_time.number_day)
    #                 print day_care
    #                 if day_care.date() == current_date:
    #                     print 111
    #                     self.is_caring = True
    #
    #     print current_date



    @api.multi
    def case_form(self):
        return {
            'name': _('Add case'),
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'crm.case',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'target': 'new',
            'readonly': True,
            'context': {
                'default_customer_id': self.id,
            },
            # 'res_id': self.id,
        }
    
    def case_list(self):
        return {
            'name':_('List'),
            'view_type':'tree',
            'view_mode':'tree',
            'res_model':'crm.case',
            'view_id':False,
            'type':'ir.actions.act_window',
            'target':'new',
            'readonly':True,
            'domain': [('contact_id','=',self.id)]
        }
    def select_default_country(self):
        vn=self.env['res.country'].search([('code','=','VN')])
        return vn.id

    def code_gender(self):
        cur_date = dt.now().strftime('%Y%m')
        last_id = str(int(self.env['res.partner'].search([], order='id desc', limit=1).id) + 1)
        day_bef = dt.now() + timedelta(days=-1)
        day_aff = dt.now() + timedelta(days=1)
        last_item = str(int(self.env['res.partner'].search_count([('create_date', '>', day_bef.strftime('%Y-%m-%d %H:%M:%S')) and ('create_date', '<=', day_aff.strftime('%Y-%m-%d %H:%M:%S'))])) + 1)
        return cur_date + '-TCB-' + last_id + '-' + last_item
    
    @api.constrains('phones')
    def check_partner_phone(self):
        self.set_primary_phone()        
        if len(self.phones) == 0:            
            raise Warning(_("Mobile number : Must be least one item"))
        elif len(self.phones) >= 1 and ('mobile' in map(lambda x:x.phone_type, self.phones) and (True not in map(lambda x: x.is_primary, self.phones))):                                      
            raise Warning(_("Mobile number : Must be least one item is primary"))
    
    @api.constrains('mobile')   
    def set_primary_phone(self):        
        phones=self.env['crm.partner_phone'].search([('customer_id','=',self.id), ('phone_type','=', 'mobile'), ('phone_number','=',self.mobile)])        
        if len(phones) == 0:            
            vals={'id':None, 'phone_number':self.mobile, 'customer_id':self.id, 'phone_type':'mobile', 'is_primary':True}            
            phones.create(vals)        
        
    @api.onchange('state_id')        
    def set_district_by_state(self):
        arr = []
        if self.state_id:
            districts = self.env['crm.district'].search([('province','=',self.state_id.id)])
            for disct in districts:
                arr.append(disct.id)        
        return {'domain': {'district': [('id','in',arr)]}}
    
    def send_direct_sms_form(self):
        phones=self.env['crm.partner_phone'].search([('phone_type','=','mobile'),('customer_id','=',self.id)])
        #print('phones: ', map(lambda x: x.phone_number, phones))
        return {
            "name": _("Create direct SMS "),
            "view_type": "form",
            "view_mode": "form",
            "res_model": "crm.sms",
            "view_id": self.env.ref('zinnia_crm.send_direct_sms_form').id,
            "type": 'ir.actions.act_window',
            "target":'new',            
            'context': {
                'default_customer_id': self.id,                
                'default_mobile': self.mobile, #map(lambda x: x.phone_number, phones),                
                'default_apm_time': dt.now().strftime('%Y-%m-%d'),
                'default_type_id': self.env['crm.sms_type'].search([('state','=', 'direct')]).id,
                'default_msg': self.env['crm.sms_type'].search([('state','=', 'direct')]).template,
            },     
        }
        
    def get_primary_phone_to_sms(self):
        print("get_primary_phone_to_sms(self)")
    
    
    