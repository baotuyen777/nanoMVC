# -*- coding: utf-8 -*-
from odoo import api, fields, models

class Employee(models.Model):
    _inherit = 'hr.employee'

    department_id = fields.Many2one('hr.department', string='Department')

