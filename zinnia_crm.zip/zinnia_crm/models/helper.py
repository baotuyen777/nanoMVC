# -*- coding:utf-8 -*-
from datetime import datetime, timedelta
def no_vn_letter(utf8_str):
    re = ''
    if utf8_str:
        VI_STR = 'ạảãàáâậầấẩẫăắằặẳẵóòọõỏôộổỗồốơờớợởỡéèẻẹẽêếềệểễúùụủũưựữửừứíìịỉĩýỳỷỵỹđẠẢÃÀÁÂẬẦẤẨẪĂẮẰẶẲẴÓÒỌÕỎÔỘỔỖỒỐƠỜỚỢỞỠÉÈẺẸẼÊẾỀỆỂỄÚÙỤỦŨƯỰỮỬỪỨÍÌỊỈĨÝỲỶỴỸĐ'
        VI_STR = [ch.encode('utf8') for ch in unicode(VI_STR, 'utf8')]
        EN_STR = 'aaaaaaaaaaaaaaaaaoooooooooooooooooeeeeeeeeeeeuuuuuuuuuuuiiiiiyyyyydAAAAAAAAAAAAAAAAAOOOOOOOOOOOOOOOOOEEEEEEEEEEEUUUUUUUUUUUIIIIIYYYYYD'    
        ustr = utf8_str.encode("utf-8")
        ustr = [ch.encode('utf8') for ch in unicode(ustr, 'utf8')]    
        for s in ustr :
            try :
                ind = VI_STR.index(s)
                re = re + EN_STR[ind]
            except Exception:
                re = re + s
                continue            
    return re

def replace_sms_temp(msg_temp='', args_dict={}):
    msg = no_vn_letter(msg_temp)   
    for key in args_dict:    
        msg = msg.replace(key, no_vn_letter(args_dict[key] if args_dict[key] != False else ''))   
    return msg

def create_sms_to_queue(self, case, sv_type, vals=None):   
        make_sms = False    
        sms_type = ''
        branch_name = '' 
        using_timeup = False      
        if sv_type == 'order' and case.is_queued == False:           
            sms_type = self.env['crm.sms_type'].search([('state', '=', sv_type)], limit=1)        
            if self.id:
                branch = self.env['crm.branch'].search([('id', '=', self.branch_id.id)], limit=1)            
                branch_name = branch.name if branch else ''
                make_sms = True
            else:                               
                branch = self.env['crm.branch'].search([('id', '=', vals['branch_id'])], limit=1)            
                branch_name = branch.name if branch else '' 
                make_sms = True            
        elif sv_type == 'using' and case.is_queued == False:             
            sms_type = self.env['crm.sms_type'].search([('state', '=', sv_type)], limit=1)
            day_s = int(case.product_id.treatment_day)   
            branch_name = case.branch_id.name 
            send_time = datetime.strptime(datetime.strftime(datetime.now(), "%Y-%m-%d"), "%Y-%m-%d").date()            
            end_time = datetime.strptime(case.apm_end_time, '%Y-%m-%d').date()            
            if send_time <= end_time:
                rem_time = datetime.strptime(case.apm_reminder_time, "%Y-%m-%d %H:%M:%S").date()
                if send_time == end_time:                    
                    rem_time = end_time                    
                    using_timeup = True    
                    case.write({'apm_reminder_time': rem_time, 'apm_time':datetime.now()}) 
                    make_sms = True                   
                elif send_time == rem_time:                                  
                    next_rem_time = rem_time + timedelta(days=day_s)                    
                    if next_rem_time <= end_time:                        
                        rem_time = next_rem_time
                    else: 
                        using_timeup = True 
                    case.write({'apm_reminder_time': rem_time, 'apm_time':datetime.now()}) 
                    make_sms = True  
        elif sv_type == 'birthday':
            sms_type = self.env['crm.sms_type'].search([('state', '=', sv_type)], limit=1) 
            make_sms = True   
        elif sv_type == 'direct':
            sms_type = self.env['crm.sms_type'].search([('state', '=', sv_type)], limit=1) 
            make_sms = True                                  
        # Make a SMS to Queue
        if make_sms:
            args_dict = {
                '[service]': '' if case is None else (case.product_id.name),
                '[location]': '' if case is None else branch_name,
                '[date]': datetime.strftime(datetime.now(), "%Y-%m-%d") if (case is None) else datetime.strftime(datetime.strptime(case.apm_time, '%Y-%m-%d %H:%M:%S'), '%d-%m-%Y'),
                '[hline]': '04 33926888',
            }
            #msg = replace_sms_temp(sms_type.template if (sv_type == 'direct') else sms_type.template, args_dict)  
            msg = replace_sms_temp(sms_type.template, args_dict)               
            sms_obj = self.env['crm.sms'].create({                            
                        'type_id': sms_type.id,
                        'state' : 'pending',
                        'msg' : msg,
                        'case_id': None if (sv_type == 'birthday' or sv_type == 'direct') else case.id,
                        'apm_time': vals['apm_time'] if (sv_type == 'birthday') else case.apm_time,
                    })
            if sv_type == 'birthday':
                self.env['crm.sms'].search([('id', '=', sms_obj.id)]).update({'customer_id':vals['customer_id'], 'mobile':vals['mobile']})
            if case and case.state == 'order':
                self.env['crm.case'].search([('id', '=', case.id)]).update({'is_queued':True})
            if case and case.state == 'using' and using_timeup == True:
                self.env['crm.case'].search([('id', '=', case.id)]).update({'is_queued':True})     
                       
def convert_datetime_to_str(datetime=datetime.now(), str_format='%Y-%m-%d %H:%m:%d'):   
    try:
        return datetime.strftime(datetime, str_format)        
    except:
        return  ''    
    
def convert_str_to_datetime(str_datetime='', str_format='%Y-%m-%d %H:%m:%d'):    
    try:
        return datetime.strptime(str_datetime, str_format)        
    except:
        return None   