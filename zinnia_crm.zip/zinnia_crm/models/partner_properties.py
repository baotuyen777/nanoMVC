# -*- coding:utf-8 -*-

from odoo import fields, models, api,_

class ContactType(models.Model):
    _name = "crm.contact_type"
    name=fields.Char(string="Description",required=True)
    code=fields.Char(string="Code",required=True)

class MemberLevel(models.Model):
    _name = "crm.member_level"
    name=fields.Char(string="Name",required=True)
    code=fields.Char(string="Code",required=True)
    
class Province(models.Model):
    _inherit='res.country.state'    
    
class District(models.Model):    
    _name = 'crm.district'
    code = fields.Char(string = 'code', required = True)
    name = fields.Char(string = 'District', required = True)
    country = fields.Many2one('res.country', string = 'Country', default=lambda self: self.env['res.country'].search([('code', '=', 'VN')], limit=1))    
    province = fields.Many2one('res.country.state', string = 'Province', required=True)   
    @api.onchange('province')
    def onchange_country(self):
        arr = []
        if self.country:
            province_id = self.env['res.country.state'].search([('country_id','=',self.country.id)])
            for prov in province_id:
                arr.append(prov.id)        
        return {'domain': {'province': [('id','in',arr)]}}
    
class Partner_Phone(models.Model):
    _name="crm.partner_phone"
    _order="phone_type asc, id desc"
    phone_type=fields.Selection([('mobile',_('Mobile type')), ('phone',_('Home Phone type'))], required=True)
    phone_number=fields.Char('Phone number', required=True)
    name=fields.Char(related='phone_number')
    is_primary=fields.Boolean('Primary phone')
    customer_id=fields.Many2one('res.partner')    
    
    _sql_constraints=[
            ('mobile_unq','UNIQUE(phone_number)', _('Phone number must be unique.')),            
        ]        
    
    @api.model
    @api.returns('self', lambda value:value.id)
    def create(self, vals):       
        creater = models.Model.create(self, vals)        
        vals['id']=creater.id
        vals['phone_number']=creater.phone_number
        vals['customer_id']=creater.customer_id.id             
        if vals and vals['phone_type']=='mobile' and vals['is_primary']==True:
            self._set_primary_phone(vals)                    
            self._update_phone_to_partner(vals)
        return creater
          
    @api.one
    def write(self, vals):
        writer=models.Model.write(self, vals)       
        if writer:            
            vals['id']=self.id
            vals['customer_id']=self.customer_id.id
            vals['phone_number']=self.phone_number
            vals['is_primary']=self.is_primary
            if vals['is_primary']==True:            
                self._set_primary_phone(vals)
                self._update_phone_to_partner(vals)           
        return writer
    
    @api.one
    def unlink(self):
        vals={}           
        vals['id']=self.id
        vals['customer_id']=self.customer_id.id
        vals['phone_number']=self.phone_number
        vals['unlink']=None 
        is_primary = self.is_primary
        deleter=models.Model.unlink(self)        
        if deleter and is_primary:
            self._update_phone_to_partner(vals) 
        return deleter
    
    def _set_primary_phone(self, vals):        
        query_cmd = """update crm_partner_phone set is_primary = False where id != """ + str(vals['id']) + """ 
                     and phone_type=\'mobile\' and is_primary=True and customer_id=""" + str(vals['customer_id'])
        return self.env.cr.execute(query_cmd) 
            
    def _update_phone_to_partner(self, vals):
        if vals: 
            customer = self.env['res.partner'].search([('id','=', vals['customer_id'])], limit=1)            
            if customer:
                customer.update({'mobile': vals['unlink'] if ('unlink' in vals) else vals['phone_number']})     
        
    