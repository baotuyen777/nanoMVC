# -*- coding:utf-8 -*-
from odoo import fields, models, api
class Department(models.Model):
    _inherit = "hr.department"
    # code=fields.Char(string="Code",required=True);
    # _sql_constraints = [ ('code_uniq',
    #      'UNIQUE (code)',
    #      'Code must be unique.'),
    #                      ]
class Job(models.Model):
    _inherit = "hr.job"
    type_id=fields.Many2one('crm.job_type','Type')