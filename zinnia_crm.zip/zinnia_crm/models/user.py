# -*- coding: utf-8 -*-
from odoo import fields, models, api


class User(models.Model):
    _inherit = 'res.users'

