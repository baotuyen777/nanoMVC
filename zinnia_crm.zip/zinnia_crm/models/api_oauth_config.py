# -*- coding:utf-8 -*-
from odoo import models, api, fields

class APIOAuthConfig(models.Model):
    _name='crm.api_oauth_config'
    _order='id desc'
    name=fields.Char('Name')
    code=fields.Selection([('getresponse', 'GetResponse'), ('other', 'Other')], string= 'Code', default='getresponse')    
    api_endpoint=fields.Char('API EndPoint')
    api_key=fields.Char('API Key')
    client_id=fields.Char('Client ID')
    token=fields.Char('Token')
    auth_type=fields.Selection([('ba', 'Basic Authentication'), ('oath2', 'OAuth 2.0')], string='OAuth type', default='ba')
    