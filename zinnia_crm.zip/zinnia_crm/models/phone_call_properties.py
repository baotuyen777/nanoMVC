# -*- coding:utf-8 -*-

from odoo import fields, models, api


class PhoneCallRating(models.Model):
    _name = "crm.phone_call_rating"
    name = fields.Char(string="Description", required=True)
    code = fields.Char(string="Code")
    remkt = fields.Boolean(string="Use Re-Mkt")



class PhoneCallPurpose(models.Model):
    _name = "crm.phone_call_purpose"
    name = fields.Char(string="Description", required=True)
    code = fields.Char(string="Code", required=True)


class PhoneCallType(models.Model):
    _name = "crm.phone_call_type"
    _order = 'order'
    name = fields.Char(string="Name", required=True)
    code = fields.Char(string="Code", required=True)

    state = fields.Selection([
        ('create', 'Create'),
        ('communicate', 'Communicate'),
        ('order', 'Order'),
        ('cancel', 'Cancel'),
        ('remaketing', 'Remaketing'),
        ('deposit', 'Deposit'),
        ('using', 'Using'),
        ('warranty', 'Warranty'),
        ('finish', 'Finish'),
    ], default='create')
    order=fields.Integer('Order')


class PhoneCallRequest(models.Model):
    _name = 'crm.phone_call_request'
    code = fields.Char(string='Code')
    name = fields.Char(string='Name')


# class PhoneCallHistory(models.Model):
#     _name = 'crm.phone_call_history'
#
#     created_by = fields.Many2one('res.users', string="Create by", default=lambda self: self.env.user.id)
#     date_create = fields.Datetime(readonly=True, default=fields.datetime.now(), required=True)
#     content = fields.Char(string="Content", autofocus=True)
#     phone_call_id = fields.Many2one('crm.phone_call')

    # _default = {
    #     'date_create': fields.datetime.now
    # }
    # @api.multi
    # def write(self, vals):
    #     vals={'date_create':fields.datetime.now()}
    #     super(History, self).write(vals)
    #     return True
class phoneCallLog(models.Model):
    _name = "crm.phone_call_log"
    _order = 'id desc'
    content=fields.Text(string="Content",required=True)
    phone_call_id = fields.Many2one('crm.phone_call')
    create_date = fields.Datetime('Create Date')
    write_date = fields.Datetime('Write Date')
    create_uid = fields.Many2one('res.users', 'Create User')
    write_uid = fields.Many2one('res.users', 'Write User')