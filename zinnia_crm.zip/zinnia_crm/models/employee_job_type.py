# -*- coding:utf-8 -*-

from odoo import fields, models, api
class JobType(models.Model):
    _name = "crm.job_type"
    name=fields.Char(string="Description",required=True)
    code=fields.Char(string="Code")
    _sql_constraints = [ ('code_uniq',
         'UNIQUE (code)',
         'Code must be unique.'),
                         ]
