# -*- coding:utf-8 -*-
from odoo import models, fields, api, exceptions
from datetime import datetime, timedelta
from helper import replace_sms_temp, create_sms_to_queue, no_vn_letter
import re

class PhoneCall(models.Model):
    _name = 'crm.phone_call'
    _order = 'id desc'
    # description=fields.Char(string='Description',required=True)
    # phone=fields.Char(string="Phone")
    date = fields.Date(string="Date", default=datetime.now().strftime("%Y-%m-%d"))
    duration = fields.Char(string="Duration", default="01:00")
    purpose_id = fields.Many2one('crm.phone_call_purpose', string="Purpose")
    created_by = fields.Many2one('res.users', string="Employee", default=lambda self: self.env.user.id, readonly=True)
    type_id = fields.Many2one('crm.phone_call_type', string="Type", required=True, help="Change status in case")
    agency_id = fields.Many2one('crm.agency', string='Agency')
    branch_id = fields.Many2one('crm.branch', string="Branch")
    maketing_channel_id = fields.Many2one('crm.maketing_channel', string="Maketing Channel")
    request_id = fields.Many2one('crm.phone_call_request', string="Request")
    description_detail = fields.Text(string="Description detail")
    require_id = fields.Many2one('crm.case_require', string='Require')
    # history_id = fields.One2many('crm.phone_call_history', 'phone_call_id', string='History')

    case_id = fields.Many2one('crm.case', string='Case')
    short_content = fields.Text('Short content', required=True)
    # extrar
    phone = fields.Char(related='case_id.customer_id.phone')
    mobile = fields.Char(related='case_id.customer_id.mobile')
    email = fields.Char(related='case_id.customer_id.email')
    # email = fields.Char(related='case_id.customer_id.email')
    customer_id = fields.Many2one(related="case_id.customer_id", readonly=True)
    # state=fields.Selection(related='case_id.state',readonly=True)
    product_id = fields.Many2one(related='case_id.product_id', string='Product/Service', readonly=True)
    prod_trm_times = fields.Integer(related='case_id.product_id.treatment_times', readonly=True)
    type_code = fields.Char(compute='_compute_type_code', default='')
    # appointment
    doctor_id = fields.Many2one('hr.employee', string="Doctor", domain1=[('job_id.type_id.code', '=', 'doctor')])
    consultant_id = fields.Many2one('hr.employee', string="Consulant")
    apm_time = fields.Datetime('Appointment time',default=datetime.now())
    rating_id = fields.Many2one('crm.phone_call_rating', string="Rating")
    log_ids = fields.One2many('crm.phone_call_log', 'phone_call_id');
    # sticker
    create_date = fields.Datetime('Create Date')
    write_date = fields.Datetime('Write Date')
    create_uid = fields.Many2one('res.users', 'Create User', readonly=True,default=lambda self: self.env.user.id)
    write_uid = fields.Many2one('res.users', 'Write User')
    def synchronous_case_create(self, vals):
        
        data = {};

        case = self.env['crm.case'].search([('id', '=', vals['case_id'])])
        # appointment
        # if vals['rating_id'] != False:
        #     data['rating_id'] = vals['rating_id']
        # if vals['apm_time'] != False:
        #     data['apm_time'] = vals['apm_time']
        # if vals['consultant_id'] != False:
        #     data['consultant_id'] = vals['consultant_id']
        # if vals['doctor_id'] != False:
        #     data['doctor_id'] = vals['doctor_id']
        if vals['date'] != False:
            data['phone_call_date_newest'] = vals['date']
        for field in vals:
            if hasattr(case, field) and vals[field]:
                data[field] = vals[field]
        # type
        type_id = vals['type_id']

        if type_id != False:
            type = self.env['crm.phone_call_type'].search([('id', '=', type_id)])           
            data['state'] = type.state                        
                
        if (type.state=='using') and (case.product_id.treatment_times > 1):
            # update sms end time for this case 
            data['apm_end_time'] = self.upd_sms_end_time(
                                                        case.product_id.treatment_times,
                                                        case.product_id.treatment_day,
                                                        data['apm_time']
                                                        )
            data['apm_reminder_time'] = vals['apm_time']
        print data
        case.write(data)
        # update to queue        
        if ((type.state=='using') and (case.product_id.treatment_times > 1)) or (type.state=='order'):        
            create_sms_to_queue(self, case, type.state, vals)

    def synchronous_case_update(self, vals_old, vals): 
                
        data = {};      
        case = vals_old['case_id']        
        # appointment
        # if 'rating_id' in vals:
        #     data['rating_id'] = vals['rating_id']
        # if  'apm_time' in vals:
        #     data['apm_time'] = vals['apm_time']
        # if 'consultant_id' in vals:
        #     data['consultant_id'] = vals['consultant_id']
        # if 'doctor_id' in vals:
        #     data['doctor_id'] = vals['doctor_id']
        # if 'branch_id' in vals:
        #     data['branch_id'] = vals['branch_id']
        for field in vals:
            if hasattr(case, field):
                data[field]=vals[field]
        # type
        type_id = self.env['crm.phone_call_type'].search([('id', '=', vals['type_id'] if ('type_id' in vals) else self['type_id'].id )])            
        data['state'] = type_id.state
        if(type_id.state=='finish'):
            data['is_queued']=True
        case.write(data)
            # update to queue
        if ((type_id.state=='using') and (case.product_id.treatment_times > 1)) or (type_id.state=='order'):        
            create_sms_to_queue(self, case, type_id.state, vals)
    @api.one
    @api.depends('type_id')
    def _compute_type_code(self):
        self.type_code = self.type_id.code

    @api.model
    def create(self, vals):
        self.synchronous_case_create(vals)
        vals['log_ids'] = [(0, 0, {
            'content': 'Khởi tạo'
        })]
        record = super(PhoneCall, self).create(vals)

        return record

    @api.multi
    def write(self, vals):       
        if(self.env.user.id != self.created_by.id):
            raise exceptions.ValidationError('You do not permission edit this record')
            return
        self.synchronous_case_update(self, vals)
        vals=self.logChanged(self,vals)
        return super(PhoneCall, self).write(vals)
    def logChanged(self,oldVal,newVal):
        content=''
        for field in newVal:

            if field in ['log_ids']:
                continue
            if hasattr(oldVal[field], 'name'):
                old ="null"
                if(bool(oldVal[field])):
                    old= oldVal[field].name + "(" + str(oldVal[field].id) + ")"
                new=self.env[oldVal[field]._name].search([('id','=',newVal[field])])
                new=new.name+"("+str(new.id)+")"
            else:

                old = oldVal[field]
                new = newVal[field]
            field_name=self.env['ir.model.fields'].search([('name','=',field)],limit=1).field_description
            content += field_name + ': ' + re.sub('<[^>]*>', '', old) + ' => ' + re.sub('<[^>]*>', '', new) + '\n'
        # print content
        if(content!=''):
            newVal['log_ids'] = [(0, 0, {
                'content': content
            })]
        return newVal

    @api.onchange('type_id')
    def get_branch(self):       
        if (self.type_id.state in ['order', 'using']):               
            self.branch_id = self.case_id.branch_id.id
           
    @api.onchange('apm_time')    
    def over_date_chg(self):
        bef_date = (datetime.now()).strftime('%Y-%m-%d') 
        if self.apm_time and (self.apm_time < bef_date):
            return {
                        'warning':{
                        'title': "Warning!",
                        'message': "The Appointment time must be equal or greater than today!",
                        },
                    }
             
    @api.constrains('apm_time')
    def over_date_cnst(self):           
        bef_date = (datetime.now()).strftime('%Y-%m-%d')        
        if self.apm_time and (self.apm_time < bef_date):             
            raise Warning('The Appointment time must be equal or greater than today!')
       
    @api.multi
    def name_get(self):
        result = []        
        if self.ensure_one():        
            name = no_vn_letter(self.case_id.name) + '-' + no_vn_letter(self.product_id.name)
            result.append((self.id, name))
        return result

    def save_popup(self):
        return {'type': 'ir.actions.act_close_wizard_and_reload_view'}    
    
    def upd_sms_end_time(self,  trm_times,trm_day,apm_time):        
        tm_days = (trm_times*trm_day)-trm_day
        return datetime.strftime(datetime.strptime(apm_time, '%Y-%m-%d %H:%M:%S') + timedelta(days=tm_days), '%Y-%m-%d')
        
