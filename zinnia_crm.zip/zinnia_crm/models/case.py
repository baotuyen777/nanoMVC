# -*- coding:utf-8 -*-
from odoo import models, fields, api, exceptions,_
from datetime import datetime,timedelta
import re
class Case(models.Model):
    _name = 'crm.case'
    _order = 'id desc'
    name = fields.Char(related='product_id.name')
    customer_id = fields.Many2one('res.partner', string="Customer")
    product_id = fields.Many2one('product.product', string='Product/Service', required=True)
    prod_trm_times = fields.Integer(related='product_id.treatment_times', readonly=True)
    product_type_name = fields.Char(related='product_id.group_id.type_id.name', string="Product type", readonly=True)
    # group_id = fields.Char(related='product_id.group_id.name', string="Product group", readonly=True)
    # ou_id = fields.Many2one('hr.department', string='Ogarnization  Unit')
    # appointment
    # created_by = fields.Many2one('res.users', string="Employee", default=lambda self: self.env.user.id, readonly=True)

    doctor_id = fields.Many2one('hr.employee', string="Doctor", domain1=[('job_id.type_id.code', '=', 'doctor')], readonly=True)
    consultant_id = fields.Many2one('hr.employee', string="Consulant", readonly=True)
    apm_time = fields.Datetime('Appointment time', readonly=True)
    apm_reminder_time = fields.Datetime('Appointment reminder time', readonly=True)
    apm_end_time = fields.Date('Appointment end time')
    apm_last_time = fields.Datetime('The last sms', related='apm_reminder_time', readonly=True)
    rating_id = fields.Many2one('crm.phone_call_rating', string="Rating", readonly=True)
    # css_id=fields.Many2one()
    created_date = fields.Datetime('Create date', readonly=True, default=fields.datetime.now())
    note = fields.Html(string="Note")
    phone = fields.Char(related='customer_id.phone')
    mobile = fields.Char(related='customer_id.mobile')
    email = fields.Char(related='customer_id.email')
    state = fields.Selection([
        ('create', 'Create'),
        ('communicate', 'Communicate'),
        ('order', 'Order'),
        ('cancel', 'Cancel'),
        ('remaketing', 'Remaketing'),
        ('deposit', 'Deposit'),
        ('using', 'Using'),
        ('warranty', 'Warranty'),
        ('finish', 'Finish'),
    ], default='create')
    phone_call_ids = fields.One2many('crm.phone_call', 'case_id', string="Phone call")
    branch_id = fields.Many2one('crm.branch', string="Branch")
    maketing_channel_id = fields.Many2one('crm.maketing_channel', string="Maketing Channel")
    agency_id = fields.Many2one('crm.agency', string='Agency')
    code = fields.Char('Code', compute='_compute_case_code', store=True)
    is_queued=fields.Boolean(default=False)
    log_ids=fields.One2many('crm.case_log','case_id');
    require_id=fields.Many2one('crm.case_require',string='Require')

    phone_call_date_newest=fields.Datetime(string='Transaction date newest')
    # extra
    # care_time_current_id=fields.Many2one('crm.care_time')
    care_time_history_id = fields.One2many('crm.case_ref_care_time_view', 'case_id', string='Care time hisstory')
    care_time_id=fields.Many2many('crm.care_time','crm_case_ref_care_time','case_id','care_time_id',string='Care time')
    is_caring = fields.Boolean('Is Caring')
    # sticker
    create_date = fields.Datetime('Create Date')
    write_date = fields.Datetime('Write Date')
    create_uid = fields.Many2one('res.users', 'Create User',readonly=True,default=lambda self: self.env.user.id)
    write_uid = fields.Many2one('res.users', 'Write User')
    # care_time_active_id=fields.Many2one('crm.care_time', compute='_get_care_time_active',store=True)
    # prod_trm_times = fields.Integer(related='product_id.treatment_times', readonly=True)
    @api.model
    def _filter_caring(self):
        return [('is_caring', '=', True)]

    def filter_doctor(self):
        doctor = self.env['hr.department'].search([('code', '=', 'doctor')])
        print doctor
        return doctor.id

    def action_finish(self):
        self.state = 'finish'

    # @api.onchange('product_id','customer_id')
    # def check_create(self):
    #     product = self.env['crm.case'].search(['&',('product_id', '=', self.product_id.id), ('customer_id', '=', self.customer_id.id)])
    #
    #     if product.id !=False:
    #         raise exceptions.ValidationError('This case existed! ')
    def show_form_transaction(self, code):
        type = self.env['crm.phone_call_type'].search([('code', '=', code)])
        context = {
            "default_case_id": self.id,
            "default_type_id": type.id,
        }
        return{
            "name":_("Create Transaction "),
            "view_type":"form",
            "view_mode":"form",
            "res_model":"crm.phone_call",
            "view_id":False,
            "type":'ir.actions.act_window',
             "target":'new',
            "readonly":True,
            "context":context,
        }
    def create_outcoming(self):
        return self.show_form_transaction("outcoming")

    def create_incoming(self):
        return self.show_form_transaction("incoming")

    def create_order(self):
        return self.show_form_transaction("order")
    def create_remaketing(self):
        return self.show_form_transaction("remaketing")
    def create_deposit(self):
        return self.show_form_transaction("deposit")
    def create_using(self):
        return self.show_form_transaction("using")

    def create_warranty(self):
        return self.show_form_transaction("warranty")

    def resend_sms(self):

        context = {
            "default_case_id": self.id,
            # "default_type_id": self.type_id,
        }
        if (self.product_id.treatment_times==1 and self.state== 'using'):
            raise exceptions.ValidationError("This treatment only use 1 times")
            return False

        return {
            "name": "Create SMS ",
            "view_type": "form",
            "view_mode": "form",
            "res_model": "crm.sms",
            "view_id": self.env.ref('zinnia_crm.sms_form_send').id,
            "type": 'ir.actions.act_window',
            "target":'new',
            "readonly": True,
            "context": context,
            # 'type': 'ir.actions.client',
            # 'tag': 'reload',
        }

    @api.one
    @api.depends('customer_id','product_id')        
    def _compute_case_code(self):  
        print('case code ', self.id)      
        c_prod = '0' if self.product_id.id == False else str(self.product_id.id)
        c_cus = '0' if self.customer_id.id == False else str(self.customer_id.id)
        c_time=str(datetime.now().strftime('%y%m'))
        c_count=str(self.env['crm.case'].search_count([('create_date','ilike',datetime.now().strftime('%Y-%m'))]))
        self.code = c_time  + '-' + c_count + '-' + c_cus + '-' + c_prod        
    
    @api.onchange('apm_reminder_time')
    def recount_remind_date(self):        
        #day_s = 0 if self.product_id.treatment_day == False else int(self.product_id.treatment_day)
        #print('days ', day_s)          
        #apm_reminder = datetime.strptime(self.apm_reminder_time, "%Y-%m-%d %H:%M:%S").date() + timedelta(days=day_s)
        #print('apm_remind ', apm_reminder)
        return 0
      
    def save_popup(self):
        return {'type': 'ir.actions.act_close_wizard_and_reload_view'}
    
    @api.multi
    def write(self, vals):              
        if 'apm_end_time' in vals and vals['apm_end_time'] != self['apm_end_time']:
            day_s = int(self.product_id.treatment_day)            
            if self.apm_reminder_time:
                vals['apm_reminder_time'] = datetime.strptime(self.apm_reminder_time, "%Y-%m-%d %H:%M:%S").date() + timedelta(days=day_s)            
            vals['is_queued'] = False
        vals =self.logChanged(self,vals)
        return models.Model.write(self, vals)

    @api.model
    @api.returns('self', lambda value: value.id)
    def create(self, vals):
        vals['log_ids'] = [(0, 0, {
                'content': 'Khởi tạo'
            })]
        return models.Model.create(self, vals)

    def logChanged(self,oldVal,newVal):
        content=''

        for field in newVal:
            # print field
            if field in ['care_time_id','log_ids','phone_call_ids','is_queued']:
                continue
            if hasattr(oldVal[field], 'name'):
                old = "null"
                if (bool(oldVal[field])):
                    old= oldVal[field].name + "(" + str(oldVal[field].id) + ")"
                # print newVal[field]
                new=self.env[oldVal[field]._name].search([('id','=',newVal[field])])
                new=new.name+"("+str(new.id)+")"
            else:
                old = oldVal[field] or "null"
                new = newVal[field]
            if(old==new):
                continue
            field_name=self.env['ir.model.fields'].search([('name','=',field)],limit=1).field_description
            content+=field_name +': '+re.sub('<[^>]*>', '', old)+' => '+re.sub('<[^>]*>', '', new)+'\n'
        # print content
        if(content!=''):
            newVal['log_ids'] = [(0, 0, {
                'content': content
            })]
        return newVal
    @api.multi
    def scan_case_care_scheduler(self):
        print 'scan case care'
        current_date = datetime.now().date()
        arr_case = self.env['crm.case'].search([('state', '=', 'using')])
        for case in arr_case:
            is_caring=False

            for care_time in case.product_id.care_time_id:
                day_care = datetime.strptime(case.apm_time, "%Y-%m-%d %H:%M:%S") + timedelta(days=care_time.number_day)
                if day_care.date() <= current_date :
                    is_satisfy = True
                    # check condition
                    if care_time.condition:
                        arr_condition = care_time.condition.split((','))
                        is_satisfy = False
                        for condition in arr_condition:
                            for care_time_his in case.care_time_history_id:
                                if care_time_his.care_name==condition:
                                    is_satisfy = True
                                    if not care_time_his.is_cared:
                                        is_satisfy = False
                                        break
                    is_caring=True
                    if(is_satisfy):
                        case.write({'care_time_id': [(4, care_time.id)]})

            # check xem da dc cham soc het chua
            is_cared_all = False
            if(bool(case.care_time_history_id)):
                is_cared_all = True
                for care_time_his in case.care_time_history_id:
                    print care_time_his.is_cared
                    if not care_time_his.is_cared:
                        is_cared_all = False
                        break
            #quyet dinh sau tinh toan
            if(is_caring and not is_cared_all):
                case.write({'is_caring': True})
                print 'have some people added'
            else:
                print 'have some people remove'
                case.write({'is_caring': False})



    def list_care(self):

        return {
            "name": "List Care time ",
            "view_type": "form",
            "view_mode": "tree",
            "res_model": "crm.case_ref_care_time_view",
            "view_id": self.env.ref('zinnia_crm.crc_tree_view').id,
            "type": 'ir.actions.act_window',
            "target": 'new',
            "readonly": True,
            "domain":[('case_id','=',self.id)],
            # "res_id"
        }
    def merge_case(self):
        print self._context.get('active_ids')
        return {
            "name": "List Care ",
            "view_type": "form",
            "view_mode": "form",
            "res_model": "crm.case_merge",
            "view_id": False,
            "type": 'ir.actions.act_window',
            "target": 'new',
            "readonly": True,
            "context": {
                "active_ids": self._context.get('active_ids'),
                # "default_case_ids": self.id,
            },
            # "domain":[('case_root_id','in',[5,6])]
            # "domain": [('case_id', '=', self.id)],
            # "res_id"
        }


