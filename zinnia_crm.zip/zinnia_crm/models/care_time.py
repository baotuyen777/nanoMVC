# -*- coding:utf-8 -*-
from odoo import models, fields, api, exceptions
from datetime import datetime

# class Care(models.Model):
#     _inherit = 'res.partner'
#     _order = 'id desc'
#     case_id=fields.One2many('crm.case','customer_id',string='Case')
    # customer_id = fields.Many2one(related="case_id.customer_id", readonly=True)
    # state=fields.Selection(related='case_id.state',readonly=True)
    # product_id = fields.Many2one(related='case_id.product_id', string='Product/Service', readonly=True)
class CareTime(models.Model):
    _name = 'crm.care_time'
    # _order = 'id desc'
    name = fields.Char('Code', required=True)
    des=fields.Char('Description')
    condition= fields.Char('required')
    number_day= fields.Integer('Number day')
    product_id=fields.Many2one('product.product','Product')
    # case_id=fields.Many2many('crm.case')

