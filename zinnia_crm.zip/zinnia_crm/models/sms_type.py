# -*- coding:utf-8 -*-
from odoo import fields, models
import logging

_logger = logging.getLogger(__name__)


class SmsType(models.Model):
    _name = "crm.sms_type"
    name= fields.Char(string='Name',required=True)
    # code = fields.Char(string='Code', required=True)
    reminder_time_before = fields.Integer(string="Reminder time before", default="1")
    unit = fields.Selection([
        ('hour', "Hour"),
        ('minute', "Minute"),
        ('day', "Day"),
        ('inday', "In Service Date"),
    ], string="Unit",default='hour')
    template = fields.Text(string='Sms template',required=False)
    reminder_time = fields.Float(string="Reminder time")
    gateway_id = fields.Many2one('crm.sms_gateway', string="SMS Gateway")
    state = fields.Selection([      
        ('order', 'Order'),
        ('using', 'Using'),        
        ('birthday', 'Birthday'),
        ('direct', 'Direct')
    ], string='SMS type name', default='order',required=True)
    
    _sql_constraints = [        
        ('state_uniq',
         'UNIQUE(state)',
         'state must be unique.'),
    ]

    
