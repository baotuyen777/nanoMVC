# -*- coding: utf-8 -*-
from odoo import fields, models, api, exceptions
from dateutil import tz
from datetime import datetime
from getresponse import GetresponseClient
from string import strip

class maketingCampaign(models.Model):
    _name = 'crm.maketing_campaign'
    _order = 'id desc'
    name = fields.Char(string='Campaign Name', required=True)
    code = fields.Char(string="Campaign Code", required=True)    
    getresponse_key = fields.Char('GetReponse key')    
    start_time = fields.Date('Start time', required=True, default=datetime.now())
    end_time = fields.Date('End time', required=True, default=datetime.now())
    ld_source = fields.Many2many('crm.lps', 'crm_campaign_ref_lps', 'campaign_id', 'lps_id', string="LD Source")
    total = fields.Integer(string="Total Partner", compute='partner_used')
    is_active = fields.Boolean('Active', default=True)
    queue_id = fields.One2many('crm.maketing_campaign_queue', 'mktc_id', 'List Queue')
    total_emails_in_queue = fields.Integer(string="Total customer email", compute='emails_in_queued')
    usr_id=fields.Integer('User ID', compute='get_usr_id')
    email_size=fields.Integer('Email size', default=0)
    @api.multi
    def partner_used(self):        
        for camp in self:
            if camp.id:
                query_cmd = 'SELECT COUNT(partner.id) AS cnt '\
                            'FROM crm_campaign_ref_lps AS camp_ref_lps '\
                            'INNER JOIN crm_maketing_campaign AS camp '\
                            'ON camp_ref_lps.campaign_id = camp.id '\
                            'INNER JOIN crm_lps AS lps '\
                            'ON lps.id = camp_ref_lps.lps_id '\
                            'INNER JOIN res_partner AS partner '\
                            'ON partner.lps_id=lps.id '\
                            'WHERE camp.id =' + str(camp.id) + \
                            ' GROUP BY camp.id '
                self.env.cr.execute(query_cmd)                
                for item in self.env.cr.fetchall():
                    camp.total = item[0]  
    
    @api.model
    @api.returns('self', lambda value:value.id)
    def create(self, vals):
        auth = self.env['crm.api_oauth_config'].search([('code', '=', 'getresponse')])
        grsp = GetresponseClient(auth.api_endpoint, auth.api_key, auth.client_id, None, None)
        cmp = grsp.post_campaign(vals['name'])   
        err = ''          
        if 'code' in cmp:            
            err = grsp.errors().get(str(cmp['code']))            
            raise exceptions.ValidationError(err)
            return False        
        if 'campaignId' in cmp:                   
            vals['getresponse_key'] = str(cmp['campaignId'])
            return models.Model.create(self, vals)   
    
    @api.multi    
    def write(self, vals):       
        auth = self.env['crm.api_oauth_config'].search([('code', '=', 'getresponse')])
        grsp = GetresponseClient(auth.api_endpoint, auth.api_key, auth.client_id, None, None)
        if ('name' in vals):            
            if 'code' not in grsp.update_campaign(self.getresponse_key, name=vals['name']) :
                return models.Model.write(self, vals)
            else :
                err = grsp.errors().get(str(cmp['code']))            
                raise exceptions.ValidationError(err)
                return False       
        return super(maketingCampaign, self).write(vals)
    
    def get_usr_id(self):        
        self.usr_id = self.env.user.id
    
    @api.one
    def emails_in_queued(self):
        arr_all_partner = []        
        cmp_queue = self.env['crm.maketing_campaign_queue'].search([('mktc_id','=',self.id)]) 
        if cmp_queue:
            for queue in cmp_queue:
                domain = eval(queue.condition)
                domain.append(['email', '!=', ''])
                arr_partner = []
                if(queue.type == 'partner'):
                    arr_partner = self.env['res.partner'].search(domain)
                else:
                    if(queue.type == 'case'):
                        arr_obj = self.env['crm.case'].search(domain)
                    if (queue.type == 'phone_call'):
                        arr_obj = self.env['crm.phone_call'].search(domain)
                    for obj in arr_obj:
                        arr_partner.append(obj.customer_id)                    
                arr_all_partner += arr_partner
        total = len(set(arr_all_partner))
        self.total_emails_in_queue = total
        
    @api.onchange('email_size')
    def format_email_size(self):        
        if self.email_size < 0:
            self.email_size = 0 
     
class maketingCampaignQueue(models.Model):
    _name = 'crm.maketing_campaign_queue'
    name = fields.Char('Name', required=True)
    condition = fields.Char('Condition', required=True,readonly='True')
    mktc_id = fields.Many2one('crm.maketing_campaign', string="Maketing campaign", required=True)
    type = fields.Selection([
        ('partner', 'Partner'),
        ('case', 'Case'),
        ('phone_call', 'Transaction'),
    ], string='Type',readonly='True')

    def synchronize_getresponse_scheduler(self):
        current_time = datetime.utcnow()
        from_zone = tz.gettz('UTC')
        to_zone = tz.gettz(self.env.user.tz) or tz.gettz('Asia/Saigon')
        hr_start = int(current_time.replace(tzinfo=from_zone).astimezone(to_zone).strftime("%H"))
        auth = self.env['crm.api_oauth_config'].search([('code', '=', 'getresponse')])
        grsp = GetresponseClient(auth.api_endpoint, auth.api_key, auth.client_id, None, None)
            
        if hr_start >= 2:  # and hr_start <= 3       
            arr_campaign = self.env['crm.maketing_campaign'].search([('is_active', '=', True), ('end_time', '<', datetime.strftime(current_time, '%Y-%m-%d'))])
                                
            for campaign in arr_campaign:
                campaign.write({'is_active':False, })                
                
            arr_campaign = self.env['crm.maketing_campaign'].search([\
                                                                   ('is_active', '=', True), \
                                                                   ('start_time', '<=', datetime.strftime(current_time, '%Y-%m-%d')), \
                                                                   ('end_time', '>=', datetime.strftime(current_time, '%Y-%m-%d'))
                                                                  ])           
            for campaign in arr_campaign:
                arr_all_partner = []                
                cmp_contacts = []
                arr_queue = campaign.queue_id
                for queue in arr_queue:
                    domain = eval(queue.condition)
                    domain.append(['email', '!=', ''])
                    arr_partner = []
                    if(queue.type == 'partner'):
                        arr_partner = self.env['res.partner'].search(domain)
                    else:
                        if(queue.type == 'case'):
                            arr_obj = self.env['crm.case'].search(domain)
                        if (queue.type == 'phone_call'):
                            arr_obj = self.env['crm.phone_call'].search(domain)
                        for obj in arr_obj:
                            arr_partner.append(obj.customer_id)                    
                    arr_all_partner += arr_partner
                    #get all email existed in this campaign
                    cmp_contacts = list(grsp.get_campaign_contacts(campaign.getresponse_key, None, None))                                                   
                arr_all_partner = list(set(arr_all_partner))
                
                #If an email don't existed in Getresponse's email list, then add it into Getresponse's contact correspond
                ct_emails = [] 
                filtered_partners=[] 
                #contacts_cnt = len(cmp_contacts)
                #contacts_size=int(campaign.email_size)
                #print('contact size: ', contacts_cnt)               
                for ct in cmp_contacts:
                    ct_emails.append(strip(ct['email']))
                for pt in arr_all_partner:
                    if strip(pt.email) not in ct_emails:
                        #if contacts_size > 0 and contacts_cnt == contacts_size:
                            #break
                        #contacts_cnt = contacts_cnt+1                        
                        filtered_partners.append(pt)                
                #Add contacts into Getresponse's campaign correspond
                grsp.post_contacts_lst(campaign.getresponse_key, filtered_partners)
                
            # print 'add_customer_queue scheduler2 running...'

    def save_popup(self):
        return {'type': 'ir.actions.act_close_wizard_and_reload_view'}
