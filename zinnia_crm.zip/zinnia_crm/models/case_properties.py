# -*- coding:utf-8 -*-
from odoo import models, fields, api
class CaseCss(models.Model):
    _name = "crm.case_css"
    name = fields.Char(string="Description", required=True)
    code = fields.Char(string="Code")
class caseLog(models.Model):
    _order = 'id desc'
    _name = "crm.case_log"

    content=fields.Text(string="Content",required=True)
    case_id = fields.Many2one('crm.case')
    create_date = fields.Datetime('Create Date')
    write_date = fields.Datetime('Write Date')
    create_uid = fields.Many2one('res.users', 'Create User')
    write_uid = fields.Many2one('res.users', 'Write User')

class caseRequire(models.Model):
    _name = 'crm.case_require'
    name=fields.Char('Name',required=True)
    code=fields.Char('Code',required=True)

class caseMerge(models.TransientModel):
    _name = 'crm.case_merge'
    case_root_id = fields.Many2one('crm.case','Choose case root',domain=lambda self:[('id','in', self._context.get('active_ids'))])

    @api.multi
    def merge(self):
        active_ids= self._context.get('active_ids')
        data={}
        list_transaction=self.env['crm.phone_call'].search([('case_id','in',active_ids)])
        case_root_id=self.case_root_id.id
        for trans in list_transaction:
            trans.write({'case_id':case_root_id})

        # remove case
        active_ids.remove(case_root_id)
        self.env['crm.case'].search([('id','in',active_ids)]).unlink()

        