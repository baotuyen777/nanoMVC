# -*- coding:utf-8 -*-
from odoo import fields, models, api
class Job(models.Model):
    _inherit = "hr.job"
    type_id=fields.Many2one('crm.job_type','Type')

