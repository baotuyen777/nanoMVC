# -*- coding:utf-8 -*-

from odoo import fields, models, api
class Ou(models.Model):
    _name = "crm.ou"
    name=fields.Char(string="Name",required=True)
    code=fields.Char(string="Code",required=True)
