import requests
from collections import defaultdict
import json
from odoo.tools.translate import _
import logging

_logger = logging.getLogger(__name__)

class GetresponseClient():
    API_ENDPOINT = None
    API_KEY = None
    X_DOMAIN = None
    X_TIME_ZONE = None
    HEADERS = None
    X_AUTH_TOKEN=None

    def __init__(self, api_endpoint, api_key, x_auth_token, x_domain = None, x_time_zone = None):       
        self.API_ENDPOINT = api_endpoint
        self.API_KEY = api_key 
        self.X_DOMAIN = x_domain
        self.X_TIME_ZONE = x_time_zone
        self.X_AUTH_TOKEN = x_auth_token
        if x_domain:
            self.HEADERS = {x_auth_token: 'api-key ' + self.API_KEY, 'X-DOMAIN': self.X_DOMAIN,
                            'Content-Type': 'application/json'}
        else:
            self.HEADERS = {x_auth_token: 'api-key ' + self.API_KEY, 'Content-Type': 'application/json'}
    
    #API properties
    def get(self, url):
        r = requests.get(self.API_ENDPOINT + url, headers=self.HEADERS)
        return r.json()

    def post(self, url, data):        
        r = requests.post(self.API_ENDPOINT + url, data=data, headers=self.HEADERS)        
        return r.json()

    def delete(self, url, data= None):
        if data:
            r = requests.delete(self.API_ENDPOINT + url, data=data, headers=self.HEADERS)
        else:
            r = requests.delete(self.API_ENDPOINT + url, headers=self.HEADERS)
        return r.text
    
    #Campaign properties
    def get_campaigns(self, query = None, sort = None, **kwargs):        
        url = str('/campaigns?')
        if query:
            for item in query:
                query_data = str(item).split('=')
                url = url + 'query[' + query_data[0] + ']=' + query_data[1] + '&'
        if sort:
            for item in sort:
                sort_data = str(item).split('=')
                url = url + 'sort[' + sort_data[0] + ']=' + sort_data[1] + '&'
        if kwargs:
            for key, value in kwargs.items():
                url = url + str(key) + '=' + str(value) + '&'
        url = url[:-1]  # get rid of last &
        r = self.get(url)
        return r
    
    def get_campaign(self, campaign_id):        
        r = self.get('/campaigns/' + campaign_id)
        return r  

    def post_campaign(self, name, **kwargs): 
        data = defaultdict()
        data['name'] = name
        data['optinTypes'] = defaultdict()
        data['optinTypes']['api']='single'      
        for key, value in kwargs.items():
            data[key] = value
        r = self.post('/campaigns', data=json.dumps(data))        
        return r

    def update_campaign(self, campaign_id, **kwargs):        
        data = defaultdict()
        for key, value in kwargs.items():
            data[key] = value       
        r = self.post('/campaigns/' + campaign_id, data=json.dumps(data))
        return r
    
    def delete_campaign(self, campaign_id, **kwargs):
        print('cam_id::', campaign_id)
        data = defaultdict()
        for key, value in kwargs.items():
            data[key] = value       
        r = self.delete('/campaigns/' + campaign_id, data=json.dumps(data))        
        return r

    def get_campaign_contacts(self, campaign_id, query= None, sort = None, **kwargs):
               
        url = str('/campaigns/' + campaign_id + '/contacts?')
        if query:
            for item in query:
                query_data = str(item).split('=')
                url = url + 'query[' + query_data[0] + ']=' + query_data[1] + '&'
        if sort:
            for item in sort:
                sort_data = str(item).split('=')
                url = url + 'sort[' + sort_data[0] + ']=' + sort_data[1] + '&'
        if kwargs:
            for key, value in kwargs.items():
                url = url + str(key) + '=' + str(value) + '&'
        url = url[:-1]  # get rid of last &
        r = self.get(url)
        return r

    #Contact properties
    def get_contacts(self, query = None, sort = None, **kwargs):        
        url = str('/contacts?')
        if query:
            for item in query:
                query_data = str(item).split('=')
                url = url + 'query[' + query_data[0] + ']=' + query_data[1] + '&'
        if sort:
            for item in sort:
                sort_data = str(item).split('=')
                url = url + 'sort[' + sort_data[0] + ']=' + sort_data[1] + '&'
        if kwargs:
            for key, value in kwargs.items():
                url = url + str(key) + '=' + str(value) + '&'
        url = url[:-1]  # get rid of last &
        r = self.get(url)
        return r

    def post_contacts(self, email, campaign_id, name, mobile):
        data = defaultdict()
        data['email'] = email
        data['campaign'] = defaultdict()
        data['campaign']['campaignId'] = campaign_id    
        data['name'] = name 
        data['mobile_phone'] = self.mobile_fomat(mobile)
        r = self.post('/contacts', data=json.dumps(data))
        _logger.info('post contacts info: ' +  str(r))
        return r
    
    def post_contacts_lst(self, campaign_id, partners=[]):
        for p in partners:
            data = defaultdict()
            data['email'] = p.email
            data['campaign'] = defaultdict()
            data['campaign']['campaignId'] = campaign_id    
            data['name'] = p.name
            print('Sent email ', p.email + ' to Getresponse with ID = ' + campaign_id)
            self.post('/contacts', data=json.dumps(data))
        return True
    
    def errors(self):
        grsp_err_code = {
                '1000':_('General error of validation process'),
                '1001':_('Resource that is related to given resource cannot be found'),
                '1002':_('Resource state forbids that kind of action'),
                '1003':_('Parameter has wrong format'),
                '1004':_('Wrong number of values for multi values parameter (hash, table)'),
                '1005':_('Parameter has empty value'),
                '1006':_('Parameter has wrong type'),
                '1007':_('Parameter value has incorrect length'),
                '1008':_('There is another resource with the same value of unique property'),
                '1009':_('Resource you tried to manipulate is used somewhere and this manipulation is forbidden'),
                '1010':_('Error in external resources'),
                '1011':_('Message is already in "sending" mode, you cannot change its properties'),
                '1012':_('Error during parsing message content'),
                '1013':_('Resource with given ID cannot be foundResource with given ID cannot be found'),
                '1014':_('Problem during authentication process'),
                '1015':_('Too many request to API, quota reached'),
                '1016':_('Too many request to API or suspected behaviour, API was temporarily blocked, please wait'),
                '1017':_('Suspected behaviour, API was permanently blocked, please contact with our support'),
                '1018':_('Your IP was blocked'),
                '1021':_('There is something wrong with your request headers')
            }
        return grsp_err_code
    
    def mobile_fomat(self, phone_no):    
        phone = str(phone_no).replace('+', '') 
        if phone[0] == '0' :
            phone = phone[1:]                
        if phone[0:2] != '84' :
            phone = '84' + phone        
        return phone

