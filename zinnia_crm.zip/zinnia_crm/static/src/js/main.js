$( "td[data-field='mark_cared']" ).html('');
$( ".btn_txt" ).addClass('abc');
//openerp.zinnia_crm = function(instance, local) {	
//console.log("function")
//	instance.web.FormView.include({
//		$("#o_field_input_6").keypress(
//					function(e){			
//						console.log("xxxxx");
//					}
//				       );
//	});
//}
