console.log(1321)

openerp.zinnia_crm = function(instance, local) {
    var _t = instance.web._t,
        _lt = instance.web._lt;
    var QWeb = instance.web.qweb;

    instance.web.ListView.include({
        render_buttons: function() {
            this._super.apply(this, arguments)
            if (this.$buttons) {
                this.$buttons.find('.oe_add_queue_getresponse').on('click', this.proxy('on_item_action_clicked'))
            }
        },
        on_item_action_clicked: function(item) {
			var model = this.getParent().dataset.model.split('.')
			var domain=(this.getParent().dataset._model._domain)
			var context = {
			    default_name:'condition_'+Math.floor((Math.random() * 100) + 1),
                default_condition: JSON.stringify(domain),
                default_type: model[1]
            }
            var action = ({
                name: "Create Queue ",
                view_type: 'form',
                view_mode: 'form',
                res_model: 'crm.maketing_campaign_queue',
                type: 'ir.actions.act_window',
                views: [[false, 'form']],
                target: 'new',
                context: context
            })
            this.do_action(action)

		}

    })
}
