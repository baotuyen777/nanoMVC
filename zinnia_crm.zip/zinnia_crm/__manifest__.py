# -*- coding: utf-8 -*-
{
    'name': "zinnia_CRM",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
       Module CRM
    """,

    'author': "Zinia",
    'website': "http://www.zinnia.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'zinnia7',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','product','hr','action_close_reload','web_m2x_options'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        # 'security/crm_security.xml',
        'views/views.xml',
        'views/templates.xml',
        'views/partner.xml',
        'views/partner_properties.xml',
        'views/case.xml',
        'views/case_properties.xml',
        'views/phone_call.xml',
        'views/phone_call_properties.xml',
        'views/product.xml',
        'views/care_time.xml',
        'views/case_ref_care_time.xml',

        'views/maketing_campaign.xml',
        'views/maketing_channel.xml',
        'views/agency.xml',
        'views/branch.xml',
        'views/employee_department.xml',

        'views/user.xml',
        'views/employee.xml',
        'views/employee_job.xml',
        'views/employee_job_type.xml',

        'views/province.xml',
        'views/district.xml',
        'views/sms.xml',
        'views/sms_type.xml',
        'views/sms_gateway.xml',
        'views/api_oauth_config.xml',

    ],
    'qweb': ['static/xml/add_queue_mkt.xml'],
    # 'auto_install': True,
    # 'installable': True,
    'application':True
}
